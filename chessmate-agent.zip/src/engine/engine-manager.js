import { logger } from '../utils/logger.js';
import { getModeConfig } from './thinking-modes.js';
import { selectShortestAndMostDirectMove } from './move-optimizer.js';

export class EngineManager {
  constructor() {
    this.worker = null;
    this.ready = false;
    this.pending = null;
    this.lastEvaluation = 0;
    this.isSearching = false;
    this.readyResolvers = [];
    this.currentCandidates = new Map();
    this.currentAnalyzingFen = null;
    this.currentAnalyzingColor = 'w';
    this.forceLocalWorker = false;
    // Stale-bestmove guard: số lượng 'bestmove' cũ đang trên đường tới (từ các
    // lần search đã bị stop). Mỗi bestmove cũ phải bị loại bỏ, không được
    // resolve promise của lần phân tích mới hơn.
    this.staleBestmoveDebt = 0;
    // Đang chờ search cũ dừng hẳn sau khi đã gửi 'stop' (chờ 'bestmove' của nó).
    // BẮT BUỘC chờ xong mới được gửi 'position' mới: Stockfish WASM xử lý
    // 'position' ngay lập tức kể cả khi search cũ còn đang unwind (ASYNCIFY),
    // mutate bàn cờ giữa chừng → crash "RuntimeError: unreachable".
    // Lưu ý: 'isready'/'readyok' KHÔNG đảm bảo search đã dừng nên không đủ.
    this.awaitingSearchEnd = false;
  }

  isContentScript() {
    return (
      typeof window !== 'undefined' &&
      window.location &&
      window.location.protocol.startsWith('http') &&
      Boolean(globalThis.chrome?.runtime?.sendMessage)
    );
  }

  waitReady(timeout = 800) {
    if (!this.worker) return Promise.resolve();
    return new Promise(resolve => {
      const timer = setTimeout(() => {
        const idx = this.readyResolvers.indexOf(resolve);
        if (idx !== -1) this.readyResolvers.splice(idx, 1);
        resolve();
      }, timeout);

      this.readyResolvers.push(() => {
        clearTimeout(timer);
        resolve();
      });

      try {
        this.worker.postMessage('isready');
      } catch (_) {
        resolve();
      }
    });
  }

  async init() {
    if (this.isContentScript() && !this.forceLocalWorker) return;
    if (this.ready && this.worker) return;

    try {
      const sfUrl = globalThis.chrome?.runtime?.getURL?.('src/engine/stockfish.js') || new URL('./stockfish.js', import.meta.url).href;
      this.worker = new Worker(sfUrl);

      this.worker.onmessage = e => this.handle(e.data);
      this.worker.onerror = err => {
        err?.preventDefault?.();
        logger.info('[ChessMate Worker] Worker error notice handled:', err?.message || err);
        try { this.worker?.terminate(); } catch (_) {}
        this.worker = null;
        this.ready = false;
        this.isSearching = false;
        this.awaitingSearchEnd = false;
        // Worker đã chết: mọi khoản nợ bestmove cũ đều vô nghĩa (bestmove của
        // search cũ sẽ không bao giờ đến). Reset để không loại nhầm bestmove
        // hợp lệ của worker mới được tạo lại sau này.
        this.staleBestmoveDebt = 0;
        if (this.pending) {
          this.pending.reject?.(new Error('Engine worker reset'));
          this.pending = null;
        }
      };

      // Send UCI handshake
      this.worker.postMessage('uci');
      await this.waitReady(1000);
      this.ready = true;
    } catch (e) {
      logger.info('Engine init notice:', e);
      throw e;
    }
  }

  handle(line) {
    const text = typeof line === 'string' ? line : line?.line || '';
    if (!text) return;

    if (text === 'readyok') {
      const resolvers = this.readyResolvers.splice(0);
      for (const r of resolvers) {
        try { r(); } catch (_) {}
      }
      return;
    }

    // Parse score and principal variations from info lines
    if (text.startsWith('info') && text.includes('score')) {
      const pvMatch = text.match(/\bpv\s+([a-h1-8qrbn\s]+)/);
      const multiPvMatch = text.match(/\bmultipv\s+(\d+)/);
      const pvStr = pvMatch ? pvMatch[1].trim() : '';
      const pvParts = pvStr ? pvStr.split(/\s+/) : [];
      const move = pvParts[0] || null;

      let scoreCp = null;
      let mateIn = null;
      let evalScore = 0;

      const cpMatch = text.match(/score\s+cp\s+(-?\d+)/);
      if (cpMatch) {
        scoreCp = parseInt(cpMatch[1], 10) / 100;
        evalScore = scoreCp;
        this.lastEvaluation = scoreCp;
      } else {
        const mateMatch = text.match(/score\s+mate\s+(-?\d+)/);
        if (mateMatch) {
          mateIn = parseInt(mateMatch[1], 10);
          evalScore = mateIn > 0 ? 999 : -999;
          this.lastEvaluation = mateIn > 0 ? `#${mateIn}` : `#${mateIn}`;
        }
      }

      if (move) {
        const mpvIndex = multiPvMatch ? parseInt(multiPvMatch[1], 10) : 1;
        this.currentCandidates.set(mpvIndex, {
          multipv: mpvIndex,
          move,
          evaluation: evalScore,
          scoreCp,
          mateIn,
          pv: pvParts
        });
      }
    }

    if (text.startsWith('bestmove')) {
      this.isSearching = false;
      // Search cũ đã dừng hẳn (dù là bestmove thật hay bị stop giữa chừng) —
      // từ giờ gửi 'position' mới là an toàn, không còn nguy cơ crash WASM.
      this.awaitingSearchEnd = false;
      // Stale-bestmove guard: bestmove này thuộc về một lần search đã bị stop
      // (xảy ra khi nước đi mới đến lúc Stockfish vừa tính xong nước cũ).
      // Loại bỏ nó để không resolve nhầm promise của lần phân tích mới hơn
      // bằng nước đi của thế cờ cũ.
      if (this.staleBestmoveDebt > 0) {
        this.staleBestmoveDebt--;
        logger.info('[ChessMate] Discarded stale bestmove from aborted search.');
        return;
      }
      if (this.pending) {
        const parts = text.split(/\s+/);
        const defaultMove = parts[1];
        const ponder = parts[3] || null;
        const p = this.pending;
        this.pending = null;

        if (!defaultMove || defaultMove === '(none)') {
          p.reject(new Error('No legal move available'));
        } else {
          const candidatesList = Array.from(this.currentCandidates.values());
          const optimal = selectShortestAndMostDirectMove({
            candidates: candidatesList,
            defaultBestMove: defaultMove,
            fen: this.currentAnalyzingFen,
            userColor: this.currentAnalyzingColor
          });

          p.resolve({
            move: optimal.move || defaultMove,
            ponder,
            evaluation: optimal.evaluation ?? this.lastEvaluation,
            mateIn: optimal.mateIn,
            efficiencyNote: optimal.efficiencyNote,
            pv: optimal.pv,
            // Top candidate moves (MultiPV) for the "top 3 suggestions" HUD.
            // Sorted by multipv rank so index 0 is always the engine's best.
            candidates: candidatesList
              .map(c => ({
                multipv: c.multipv,
                move: c.move,
                evaluation: c.evaluation,
                scoreCp: c.scoreCp,
                mateIn: c.mateIn
              }))
              .sort((a, b) => a.multipv - b.multipv)
          });
        }
      }
    }
  }

  ensureEngineIframe() {
    if (typeof document === 'undefined') return null;
    let frame = document.getElementById('chessmate-engine-frame');
    if (!frame) {
      frame = document.createElement('iframe');
      frame.id = 'chessmate-engine-frame';
      frame._isReady = false;
      frame.addEventListener('load', () => {
        frame._isReady = true;
      });
      frame.src = globalThis.chrome?.runtime?.getURL?.('src/offscreen/offscreen.html') || '';
      frame.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:1px;height:1px;border:none;opacity:0;pointer-events:none;z-index:-1;';
      (document.body || document.documentElement).appendChild(frame);
    }
    return frame;
  }

  analyzeViaIframe(fen, config, targetDepth, targetMovetime, modeKey) {
    const frame = this.ensureEngineIframe();
    if (!frame) return Promise.reject(new Error('IFrame unavailable'));

    return new Promise((resolve, reject) => {
      const reqId = 'cm_' + Math.random().toString(36).slice(2, 9);
      let isSettled = false;

      const onMessage = (event) => {
        if (event.data?.target !== 'chessmate_content') return;
        if (event.data?.type === 'OFFSCREEN_READY') {
          frame._isReady = true;
          return;
        }
        if (event.data?.id !== reqId) return;

        isSettled = true;
        window.removeEventListener('message', onMessage);
        this.contentScriptPending = null;
        if (event.data.success) {
          resolve(event.data.result);
        } else {
          reject(new Error(event.data.error || 'IFrame analysis failed'));
        }
      };

      this.contentScriptPending = {
        resolve,
        reject,
        cancel: () => {
          isSettled = true;
          window.removeEventListener('message', onMessage);
          try {
            frame.contentWindow?.postMessage({ target: 'offscreen', type: 'OFFSCREEN_STOP' }, '*');
          } catch (_) {}
          reject(new Error('Cancelled'));
        }
      };

      window.addEventListener('message', onMessage);

      const sendReq = () => {
        try {
          frame.contentWindow?.postMessage({
            target: 'offscreen',
            type: 'OFFSCREEN_ANALYZE',
            id: reqId,
            fen,
            config: {
              skillLevel: config.skillLevel ?? 20,
              depth: targetDepth,
              movetime: targetMovetime,
              thinkingMode: modeKey
            }
          }, '*');
        } catch (e) {
          if (!isSettled) {
            window.removeEventListener('message', onMessage);
            reject(e);
          }
        }
      };

      // NEVER read frame.contentDocument as it triggers SecurityError: The operation is insecure
      if (frame._isReady) {
        sendReq();
      } else {
        frame.addEventListener('load', () => {
          frame._isReady = true;
          sendReq();
        }, { once: true });
        setTimeout(sendReq, 250);
      }

      setTimeout(() => {
        if (!isSettled) {
          window.removeEventListener('message', onMessage);
          reject(new Error('IFrame engine calculation timeout'));
        }
      }, targetMovetime + 5000);
    });
  }

  async getBestMove(fen, config = {}) {
    const modeKey = config.thinkingMode || 'mate_hunt';
    const modeCfg = getModeConfig(modeKey);
    const targetDepth = Math.max(5, (config.depth ?? 16) + modeCfg.depthBonus);
    const targetMovetime = Math.round((config.movetime ?? 1600) * modeCfg.movetimeMultiplier);

    // If running in a webpage context (content script), try background offscreen or extension iframe
    if (this.isContentScript()) {
      this.stop();
      try {
        const bgResult = await new Promise((resolve, reject) => {
          let isCancelled = false;
          this.contentScriptPending = {
            resolve,
            reject,
            cancel: () => {
              isCancelled = true;
              reject(new Error('Cancelled'));
            }
          };

          chrome.runtime.sendMessage(
            {
              type: 'ANALYZE_POSITION',
              fen,
              config: {
                skillLevel: config.skillLevel ?? 20,
                depth: targetDepth,
                movetime: targetMovetime,
                thinkingMode: modeKey
              }
            },
            response => {
              if (isCancelled) return;
              this.contentScriptPending = null;
              if (chrome.runtime.lastError) {
                return reject(new Error(chrome.runtime.lastError.message));
              }
              if (!response || !response.success) {
                return reject(new Error(response?.error || 'Engine calculation failed'));
              }
              resolve(response.result);
            }
          );
        });
        return bgResult;
      } catch (err) {
        if (err.message === 'Cancelled') throw err;
        logger.info('[ChessMate] Background route notice:', err?.message || err, '- Trying extension iframe fallback');
        // ALWAYS use analyzeViaIframe in content script on mobile / WebKit.
        // NEVER attempt new Worker() in content script because WebKit throws 'SecurityError: The operation is insecure'
        return await this.analyzeViaIframe(fen, config, targetDepth, targetMovetime, modeKey);
      }
    }

    // Direct / Local worker context: run Stockfish directly
    if (!fen || typeof fen !== 'string' || fen.split(' ').length < 2) {
      throw new Error('Invalid FEN provided for analysis');
    }

    const skillLevel = config.skillLevel ?? 20;
    await this.init();

    // If already searching or pending, safely stop and wait for engine to settle.
    // QUAN TRỌNG: phải chờ search cũ dừng hẳn (nhận 'bestmove' của nó) rồi
    // mới gửi 'position' mới — nếu không WASM crash "unreachable" (đã tái hiện
    // và xác minh bằng stress test). waitReady() một mình KHÔNG đủ.
    if (this.isSearching || this.pending) {
      this.stop();
      await this.waitForSearchEnd(2000);
      await this.waitReady(500);
    }
    this.lastEvaluation = 0;
    this.isSearching = true;
    this.currentAnalyzingFen = fen;
    this.currentAnalyzingColor = fen.split(' ')[1] || 'w';
    this.currentCandidates.clear();

    return new Promise((resolve, reject) => {
      this.pending = { resolve, reject };

      try {
        this.worker?.postMessage(`setoption name Skill Level value ${skillLevel}`);
        this.worker?.postMessage('setoption name MultiPV value 3');
        this.worker?.postMessage(`setoption name Contempt value ${modeCfg.contempt ?? 80}`);
      } catch (_) {}

      try {
        this.worker?.postMessage(`position fen ${fen}`);
        this.worker?.postMessage(`go depth ${targetDepth} movetime ${targetMovetime}`);
      } catch (err) {
        this.isSearching = false;
        this.pending = null;
        return reject(err);
      }

      const timeoutMs = targetMovetime + 4500;
      setTimeout(() => {
        if (this.pending?.resolve === resolve) {
          try { this.worker?.postMessage('stop'); } catch (_) {}
          this.isSearching = false;
          this.pending = null;
          reject(new Error('Engine calculation timeout'));
        }
      }, timeoutMs);
    });
  }

  /**
   * Chờ search cũ dừng HẲN sau khi đã gửi 'stop' (tức là đã nhận 'bestmove'
   * của nó). Khác với waitReady(): 'readyok' trả lời ngay cả khi search cũ
   * còn đang unwind trong WASM — gửi 'position' lúc đó sẽ crash engine
   * ("RuntimeError: unreachable"). Luôn có timeout để không kẹt.
   */
  waitForSearchEnd(timeout = 2000) {
    if (!this.awaitingSearchEnd) return Promise.resolve();
    return new Promise(resolve => {
      const start = Date.now();
      const iv = setInterval(() => {
        if (!this.awaitingSearchEnd || !this.worker || Date.now() - start >= timeout) {
          clearInterval(iv);
          this.awaitingSearchEnd = false;
          resolve();
        }
      }, 20);
    });
  }

  stop() {
    if (this.isContentScript()) {
      if (this.contentScriptPending) {
        this.contentScriptPending.cancel?.();
        this.contentScriptPending = null;
      }
      try {
        const frame = document.getElementById('chessmate-engine-frame');
        frame?.contentWindow?.postMessage({ target: 'offscreen', type: 'OFFSCREEN_STOP' }, '*');
      } catch (_) {}
      chrome.runtime?.sendMessage?.({ type: 'STOP_ANALYSIS' })?.catch?.(() => {});
      if (!this.forceLocalWorker) return;
    }

    if (this.isSearching && this.worker) {
      try {
        this.worker.postMessage('stop');
      } catch (_) {}
      // Engine đang search: Stockfish chắc chắn sẽ (hoặc đã) trả về một
      // 'bestmove' cho lần search này. Ghi nợ để loại bỏ nó khi đến,
      // tránh resolve nhầm promise của lần phân tích mới.
      this.staleBestmoveDebt++;
      // Đánh dấu đang chờ search cũ dừng hẳn — getBestMove() sẽ chờ cờ này
      // trước khi gửi 'position' mới (chống crash WASM, xem constructor).
      this.awaitingSearchEnd = true;
    }
    this.isSearching = false;

    if (this.pending) {
      this.pending.reject?.(new Error('Cancelled'));
      this.pending = null;
    }
  }

  destroy() {
    this.stop();
    this.worker?.terminate();
    this.worker = null;
    this.ready = false;
  }
}
